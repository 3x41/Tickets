<?php
header('Location: user_log_ticket.php');
?>

<?=login_header('Create Ticket')?>

<div class="content create">
	<h2>Redirect to create ticket.</h2>
  
</div>

<?=template_footer()?>
